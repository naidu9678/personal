alter table ACT_HI_PROCINST
	add NAME_ nvarchar(255);
	
